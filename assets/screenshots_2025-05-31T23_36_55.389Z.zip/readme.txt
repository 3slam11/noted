These screenshots are made with Progressier (https://progressier.com) — the all-in-one PWA toolkit.

Wanna edit these screenshots?
Import the raw.SCREENSHOTS file at https://progressier.com/pwa-screenshots-generator